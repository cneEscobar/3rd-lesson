public enum ColorCats {
    WHITE,
    BLACK,
    BLACK_AND_WHITE,
    GINGER,
    SMOKY,
    HAIRLESS,
    BROWN,
    MULTICOLOR
}
